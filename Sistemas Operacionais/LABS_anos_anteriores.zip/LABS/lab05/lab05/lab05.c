/**
 * Sistemas Operacionais - 2018
 * Laboratório 5: Serviço local de backup transparente
 *
 * Nomes: Guilherme Felipe Reis Duarte      RA: 120805
 *        Renata Sendreti Broder            RA: 112347
 *
 * Data : 04/07/2018
 *
 */


#include "sha1.c"
#include <assert.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>

#define INTERVALO   100000          // Intervalo entre execuções do laço infinito, em *microssegundos* = 10^-3 milissegundos.

#define DIR_PADRAO  "./pasta"
#define BAK_PADRAO  "./pasta_backup"

#define MAX_ARQUIVOS 5000   // capacidade da tabela de arquivos, para armazenar na tabela de arquivos e backups
#define BLOCO        4096
#define COMPR_DIR     256
#define COMPR_HASH     50    // confirmar este tamanho

/* Estruturas de dados */
/**
 * InfoArquivo: armazena as informações básicas sobre um arquivo.
 */
typedef struct
{
    ino_t inode;                    // número do i-node
    char  nome[COMPR_DIR];          // "lab5.c"
    char  caminho[COMPR_DIR];       // "./pasta/"
    long long unsigned int tam;     // tamanho em bytes
} InfoArquivo;

InfoArquivo *info_novo(struct dirent *);                                    // Cria estrutura InfoArquivo a partir de seu dirent
InfoArquivo *criar_backup(InfoArquivo *arq_original, const char *);    // Cria backup do arquivo original dado. Retorna o InfoArquivo no backup.
char *caminho_completo(InfoArquivo *, char *buf);

/**
 * EntradaTabela
 * Uma entrada na tabela de arquivos.
 * Cada entrada associa o i-node de um arquivo na pasta monitorada
 * ao i-node de um arquivo na pasta de backup.
 */
typedef struct
{
    InfoArquivo *original;
    InfoArquivo *backup;
} EntradaTabela;

EntradaTabela *entrada_nova(struct dirent *origem);      // Cria entrada da tabela a partir da estrutura dirent do arquivo de origem

typedef struct No
{
    EntradaTabela *registro;
    struct No *prox;
} No;

void destruir_lista(No *);

/**
 * TabelaArquivos
 * Uma tabela que relaciona cada arquivo na pasta monitorada
 * com os arquivos na pasta backup.
 */
typedef struct
{
    char dir_mon[COMPR_DIR];    // "./pasta"
    char dir_bak[COMPR_DIR];    // "./pasta_backup"

    No *inicio;                 // implementado como lista encadeada

    /* O ideal talvez seria implementar como uma árvore  (buscas, inserções e remoções rápidas)
    e usar o inode como chave. Tal implementação, porém, levaria muito tempo para ser feita */
} TabelaArquivos;

TabelaArquivos *tabela_criar(char *, char *);                   // cria uma nova tabela
void            tabela_novo_arquivo(struct dirent *dirent_orig);// Cria uma nova entrada na tabela de arquivos e a insere na tabela.
void            tabela_inserir(EntradaTabela *);                // insere um registro na tabela de arquivos
EntradaTabela  *tabela_localizar_orig(No *, ino_t inode);       // retorna a entrada na tabela cujo arquivo original tenha o inode dado.


/* ---------------------------------------------------- */
/* Variaveis globais */
bool finalizar;
pthread_t id_thread;
TabelaArquivos *tabela;


/* --- Funções auxiliares --- */
void hash(char *palavra, int nbytes, char hexResult[41]);
struct dirent *array_buscar(struct dirent **, int, ino_t);
int copiar_arquivo(char *origem, char *destino);

/* --- Funções do backup --- */
void iniciar_backup(char *, char *);
void *monitorar(void *arg);
void atualizar(EntradaTabela *, struct dirent **, int);
int atualizar_backup(int fd_orig, int fd_backup);
void remover_excluidos();
void buscar_deletar(struct dirent **backups, int b);
void finalizar_backup();


/* --- função principal --- */
int main(int argc, char *argv[])
{

    char nome_dir_mon[COMPR_DIR];
    char nome_dir_bak[COMPR_DIR];

    // Verifica o número de argumentos
    if (argc == 1)
    {
        // pastas padrão
        printf("Executando programa usando pastas padrao.\n");
        strcpy(nome_dir_mon, DIR_PADRAO);
        strcpy(nome_dir_bak, BAK_PADRAO);
    }

    else if (argc == 3)
    {
        // pastas recebidas como entrada
        printf("Executando programa usando pastas dadas.\n");
        strcpy(nome_dir_mon, argv[1]);
        strcpy(nome_dir_bak, argv[2]);
    }

    // Numero incorreto de argumentos
    else
    {
        printf("Uso:\n");
        printf("%s\n", argv[0]);
        printf("%s <pasta monitorada> <pasta backup>\n", argv[0]);
        return -1;
    }

    // inicia backup
    iniciar_backup(nome_dir_mon, nome_dir_bak);

    // cria a thread para monitorar os arquivos
    if ( (pthread_create(&id_thread, NULL, monitorar, NULL)) == -1)
    {
        perror("Nao foi possivel criar thread");
        return -1;
    }

    // Aguarda usuário finalizar o programa
    char c;
    printf("Pressione enter para finalizar o programa.\n");
    scanf("%c", &c);

    // Encerra as atividades
    finalizar_backup();
    return 0;
}

/* ------------------------------------------------ */
/* Funções auxiliares */
/**
 * Calcula o hash de uma palavra dada e salva em resultado.
 *
 * palavra   = conjunto de bytes para calcular o hash
 * nbytes    = comprimento da palavra
 * hexResult = onde salvar o hash.
 *
 * https://www.devmedia.com.br/forum/sha1-ou-md5/580909
 *
 */
void hash(char *palavra, int nbytes, char hexResult[41])
{
    char hashHex[21];
    bzero(hexResult, 41);

	SHA1(hashHex, palavra, nbytes);

    int offset;
    for (offset = 0; offset < 20; offset++)
        sprintf( ( hexResult + (2*offset)), "%02x", hashHex[offset]&0xff);
}


/**
 * Busca pelo array gerado pelo scandir por um inode específico.
 * Retorna a estrutura encontrada, ou NULL se ela não estiver presente.
 */
struct dirent *array_buscar(struct dirent **lista, int n, ino_t inode)
{
    int i;
    for (i = 0; i < n; i++)
    {
        if (lista[i]->d_ino == inode)
        {
            // sucesso
            return lista[i];
        }
    }

    // nao encontrado
    return NULL;
}

/* Funções que fazem o backup */

/**
 * iniciar_backup()
 *
 * Inicia as variáveis globais.
 * Verifica se pastas existem; cria as pastas caso contrário.
 */
void iniciar_backup(char *nome_dir_mon, char *nome_dir_bak)
{
    // Cria tabela de arquivos vazia
    tabela = tabela_criar(nome_dir_mon, nome_dir_bak);

    // Verifica se diretórios existem e os cria, caso contrário.
    // https://stackoverflow.com/questions/7430248/creating-a-new-directory-in-c
    struct stat st;
    int res;
    if (stat(nome_dir_mon, &st) == -1)
    {
        res = mkdir(nome_dir_mon, 0777);
        if (res == -1)
        {
            perror("Nao foi possivel criar diretorio de monitoramento.");
        }
    }

    if (stat(nome_dir_bak, &st) == -1)
    {
        mkdir(nome_dir_bak, 0777);
        if (res == -1)
        {
            perror("Nao foi possivel criar diretorio de backup.");
        }
    }

    // Por enquanto é só. A tabela será construída na primeira execução da thread
    // de monitoramento.
}


/**
 * monitorar()
 * Monitora a pasta dir_mon. É executada por uma thread auxiliar.
 * Passos:
 *
 * 1. Obtém a lista de todos os arquivos atualmente na pasta monitorada
 * 2. Para cada arquivo, verifica se já há uma entrada desse arquivo na
 *    tabela de arquivos - a verificação é feita pelo seu i-node.
 * 3. Se não existir, o arquivo é novo:
 *    3.1 *Copia* o arquivo para o diretorio de backup
 *    3.2 Cria uma entrada na tabela para esse arquivo.
 *
 * 4. Se existir, verifica se houve alterações no arquivo em relação ao backup.
 *    4.1 Se houve alterações (diferença de hash entre arquivo atual e o backup),
 *        *atualiza* o backup.
 *    4.2 Caso contrário, não faz nada.
 *
 * 5. Por fim, percorre a tabela em busca de arquivos que não existem mais na pasta
 *    monitorada.
 *    5.1 Se encontrado, apaga o arquivo de backup e remove a entrada da tabela de
 *        arquivos.
 *
 */
void *monitorar(void *arg)
{
    // inicia laço infinito
    finalizar = false;          // é depois alterado pela thread principal para encerrar o laço
    while (!finalizar)
    {
        // 1. Obtém lista de arquivos de ambas as pastas
        int i;
        struct dirent **originais, **backups;

        int n_orig = scandir(tabela->dir_mon, &originais, NULL, alphasort);
        if (n_orig < 0)
        {
            perror("Erro ao obter a lista de arquivos no diretorio monitorado");
            exit(-1);
        }

        int n_back = scandir(tabela->dir_bak, &backups, NULL, alphasort);
        if (n_back < 0)
        {
           perror("Erro ao obter a lista de arquivos no diretorio de backup");
           exit(-1);
        }

        // 2. Percorre a lista de arquivos na pasta monitorada
        for (i = 0; i < n_orig; i++)
        {
            // Analisa somente se não for diretório
            if (originais[i]->d_type == DT_REG)
            {
                // Procura um registro na tabela de arquivos referente ao arquivo atual
                EntradaTabela *entrada = tabela_localizar_orig(tabela->inicio, originais[i]->d_ino); // localiza entre arquivos originais

                // 3. Se não existe entrada na tabela, cria o backup do arquivo
                if (entrada == NULL)
                {
                    tabela_novo_arquivo(originais[i]);    // insere arquivo entre os backups usando o seu struct dirent.
                }

                // Se existir, atualiza o arquivo
                else
                {
                    // Atualiza nome do arquivo
                    if (strcmp(entrada->original->nome, originais[i]->d_name) != 0)
                    {
                        strcpy(entrada->original->nome, originais[i]->d_name);
                    }

                    // obtém atributos do arquivo original
                    char nome_completo[COMPR_DIR];
                    strcpy(nome_completo, entrada->original->caminho);  //            "./pasta/"
                    strcat(nome_completo, entrada->original->nome);     // Resultado: "./pasta/lab5.c"

                    struct stat stat_orig;
                    int x = stat(nome_completo, &stat_orig);
                    if (x == -1)
                    {
                        perror("Erro ao obter status de um arquivo monitorado.");
                        exit(-1);
                    }

                    // Atualiza tamanho do arquivo
                    entrada->original->tam = stat_orig.st_size;

                    // Atualiza o conteúdo do backup
                    atualizar(entrada, backups, n_back);
                }
            }

            // free no dirent atual
            free(originais[i]);

        }

        // free na lista de arquivos na pasta monitorada
        free(originais);

        // 5. Remover entradas da tabela cujos arquivos de origem foram excluídos
        remover_excluidos();

        // 6. Excluir arquivos de backup não mais relacionados a arquivos na tabela
        buscar_deletar(backups, n_back);

        // libera a lista de arquivos da pasta de backup
        for (i = 0; i < n_back; i++)
        {
            free(backups[i]);
        }
        free(backups);
        // aguarda alguns milissegundos antes de reiniciar laço
        usleep(INTERVALO);
    }

    return NULL;
}

/**
 * Dada uma entrada de tabela de arquivos, atualiza o arquivo monitorado em questão.
 *  - entrada   = entrada da tabela
 *  - backups   = lista de dirents dos arquivos localizados na pasta de backup.
 *                É usado para verificar se o arquivo ainda existe.
 *  - n_dirents = nº de dirents em backups.
 */
void atualizar(EntradaTabela *entrada, struct dirent **backups, int n_dirents)
{
    // Localiza o arquivo backup pelo índice de seu i-node.
    // Faz novo backup se não existir.
    struct dirent *backup = array_buscar(backups, n_dirents, entrada->backup->inode);
    if (backup == NULL)
    {
        free(entrada->backup);  // libera InfoArquivo antigo
        entrada->backup = criar_backup(entrada->original, tabela->dir_bak);
    }

    // Atualiza as informações do arquivo
    else
    {
        // Obter caminhos completos
        char caminho_orig[COMPR_DIR], caminho_backup_antigo[COMPR_DIR], caminho_backup_novo[COMPR_DIR];

        // Arquivo original e backup
        caminho_completo(entrada->original, caminho_orig);
        caminho_completo(entrada->backup,   caminho_backup_antigo);

        // backup: caminho completo para o nome novo, caso tenha sido renomeado
        strcpy(caminho_backup_novo, entrada->backup->caminho);
        strcat(caminho_backup_novo, entrada->original->nome);

        // Verifica nome do arquivo; renomear backup se houve mudança.
        if (strcmp(caminho_backup_antigo, caminho_backup_novo) != 0)
        {
            rename(caminho_backup_antigo, caminho_backup_novo);
            strcpy(entrada->backup->nome, entrada->original->nome);             // renomeia nome na tabela também
        }


        // Atualizar conteúdo: Abre ambos os arquivos para verificar seu conteúdo
        int fd_orig = open(caminho_orig, O_RDONLY);
        if (fd_orig == -1) {
            perror("Nao foi possivel abrir o arquivo original");
            exit(-1);
        }

        int fd_backup = open(caminho_backup_novo, O_RDWR, O_APPEND);
        if(fd_backup == -1) {
            perror("Nao foi possivel abrir o arquivo backup");
            exit(-1);
        }
        atualizar_backup(fd_orig, fd_backup);

        // Atualiza tamanho do backup
        entrada->backup->tam = entrada->original->tam;

        // fecha arquivos
        close(fd_orig);
        close(fd_backup);
    }
}


/**
 * Dados os file descriptors do arquivo de origem e o de backup,
 * Copia blocos do arquivo de origem para o de backup, desde
 * que os blocos sejam diferentes.
 */
int atualizar_backup(int fd_orig, int fd_backup)
{
    char buff_orig[BLOCO], buff_backup[BLOCO];
    int tam_orig, tam_backup, cursor_backup, cursor_orig, wb;

    tam_orig = read(fd_orig, buff_orig, BLOCO);
    tam_backup = read(fd_backup, buff_backup, BLOCO);
    cursor_backup = tam_backup;
    cursor_orig = tam_orig;

    while(tam_orig > 0)
    {
        // cria buffers para os hashes
        char buff1[50], buff2[50];
        bzero(buff1, 50);
        bzero(buff2, 50);

        // Compara blocos dos arquivos, se for diferente, reescreve no backup
        hash(buff_orig, tam_orig, buff1);
        hash(buff_backup, tam_backup, buff2);
        if(strcmp(buff1, buff2) != 0)
        {
            if(cursor_backup - tam_orig < 0) cursor_backup = 0;
            else cursor_backup = cursor_orig - tam_orig;

            lseek(fd_backup, cursor_backup, SEEK_SET);
            wb = write(fd_backup, buff_orig, tam_orig);
            if(wb == -1){
                perror("Nao foi possivel escrever no arquivo");
                return -1;
            }
            cursor_backup += tam_orig;
        }
        tam_orig = read(fd_orig, buff_orig, BLOCO);
        if(tam_orig == -1){
            perror("Nao foi possivel ler o arquivo");
            return -1;
        }
        tam_backup = read(fd_backup, buff_backup, BLOCO);
        if(tam_backup == -1){
            perror("Nao foi possivel ler o arquivo");
            return -1;
        }
        cursor_backup += tam_backup;
        cursor_orig += tam_orig;
    }
    ftruncate(fd_backup, cursor_orig);
}


/**
 * Percorre a tabela de arquivos e remove as entradas cujos arquivos de originais
 * tenham sido excluídos.
 */
void remover_excluidos()
{
    // percorre tabela
    No *percorrer = tabela->inicio;
    No *anterior = percorrer;
    while (percorrer != NULL)
    {
        // monta caminho
        char caminho[COMPR_DIR];
        caminho_completo(percorrer->registro->original, caminho);

        // Remove entrada da tabela se o arquivo não existir
        if (access(caminho, F_OK) == -1)
        {
            // trata o caso de a entrada a ser removida é o primeiro elemento
            if (percorrer == anterior)
            {
                tabela->inicio = tabela->inicio->prox;
                free(percorrer->registro->original);
                free(percorrer->registro->backup);
                free(percorrer->registro);
                free(percorrer);
                percorrer = tabela->inicio;
                anterior = tabela->inicio;
                continue;
            }

            // Outros casos
            else
            {
                anterior->prox = percorrer->prox;
                free(percorrer->registro->original);
                free(percorrer->registro->backup);
                free(percorrer->registro);
                free(percorrer);
                percorrer = anterior;   // para que o ponteiro anterior permaneça onde está
            }
        }

        // próximo elemento
        anterior = percorrer;
        percorrer = percorrer->prox;
    }
}

/**
 * Parte do monitoramento que apaga arquivos de backup que não estão
 * mais atrelados a um arquivo na pasta monitorada.
 */
void buscar_deletar(struct dirent **backups, int b)
{

    int i, v;
    No *percorre;

    // Para cada arquivo na pasta de backup...
    for(i=0; i<b; i++)
    {
        // verifica se há uma entrada de tabela ligado a ele.
        percorre = tabela->inicio;
        v = -1;
        while(percorre != NULL)
        {
            if(percorre->registro->backup->inode == backups[i]->d_ino) v = 1;
            percorre = percorre->prox;
        }


        // se não houver, apaga-o
        if(v == -1)
        {
            char rem[COMPR_DIR];
            strcpy(rem, tabela->dir_bak);
            strcat(rem, "/");
            remove(strcat(rem, backups[i]->d_name));
        }
    }
}

/**
 * libera todas as estruturas de dados utilizada pelo programa
 */
void finalizar_backup()
{
    // encerra thread
    finalizar = true;
    pthread_join(id_thread, NULL);

    // libera memória
    destruir_lista(tabela->inicio);
    free(tabela);
}


/* -------------------------------------- */
/* Funções que operam sobre as estruturas */

/**
 * Dado um InfoArquivo, salva o nome completo do arquivo em buf.
 * Retorna o ponteiro buf.
 */
char *caminho_completo(InfoArquivo *arq, char *buf)
{
    bzero(buf, COMPR_DIR);
    strcpy(buf, arq->caminho);
    strcat(buf, arq->nome);
    return buf;
}

/**
 * criar_backup()
 *
 * Faz uma cópia do arquivo original para a pasta de backup.
 * Após copiar, retorna as informações do arquivo criado.
 *
 * formato de dir_destino: "./pasta_backup/"    (com '/' no final)
 *
 * forçando dir_destino ser constante, para a função não alterá-la.
 */
InfoArquivo *criar_backup(InfoArquivo *arq_original, const char *dir_destino)
{
    // acrescenta '/' ao final de dir_destino, se necessário
    char origem[COMPR_DIR], destino[COMPR_DIR];
    bzero(origem, COMPR_DIR);
    bzero(destino, COMPR_DIR);

    // começa a montar o caminho destino, onde será criado o backup
    strcpy(destino, dir_destino);

    if (destino[strlen(destino) - 1] != '/')
        strcat(destino, "/");

    // obtém caminhos completos dos arquivos
    caminho_completo(arq_original, origem);
    strcat(destino, arq_original->nome);

    // Cria cópia do arquivo original
    if (copiar_arquivo(origem, destino) < 0)
    {
        perror("Nao foi possivel criar backup");
        exit(-1);
    }

    // Obtém o dirent do novo arquivo criado
    struct dirent **lista;
    int filtro(const struct dirent *arq) { return strcmp(arq->d_name, arq_original->nome) == 0; };  // filtro para obter somente o arquivo desejad
    scandir(tabela->dir_bak, &lista, filtro, alphasort);
    struct dirent *dirent_backup = lista[0];

    // Salva as informações do arquivo novo
    InfoArquivo *arq_backup = (InfoArquivo *) malloc(sizeof(InfoArquivo));
    arq_backup->inode = dirent_backup->d_ino;
    arq_backup->tam   = arq_original->tam;
    strcpy(arq_backup->caminho, tabela->dir_bak);
    strcat(arq_backup->caminho, "/");
    strcpy(arq_backup->nome, arq_original->nome);

    // libera a memória usada pelo dirent
    free(dirent_backup);
    free(lista);
    return arq_backup;
}

/**
 * copiar_arquivo()
 * Copia o arquivo origem para o arquivo destino.
 */
int copiar_arquivo(char *origem, char *destino)
{
    int fd_orig, fd_backup;

    // Abre origem
    fd_orig = open(origem, O_RDONLY);
	if (fd_orig == -1){
		perror("Nao foi possivel abrir o arquivo");
        return -1;
	}

    // Abre destino
	mode_t mode = S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH;
	fd_backup = open(destino, O_CREAT | O_WRONLY, mode);
	if(fd_backup == -1) {
		perror("Nao foi possivel abrir o arquivo");
		close(fd_orig);
        return -1;
	}

    // Copia blocos do arquivo origem para o destino
	int nr, ns, nw, n;
	char buffer[BLOCO];
	void *ptr_buff;
	do {
		nr = read(fd_orig, buffer, BLOCO);
		if (nr == -1) {
			perror("Nao foi possivel ler o arquivo");
			close(fd_orig);
			close(fd_backup);
			return -1;
		}
		else if (nr > 0) {
			ptr_buff = buffer;
			nw = nr;
			ns = 0;
			do {
				n = write(fd_backup, ptr_buff + ns, nw);
				if (n == -1) {
					perror("Nao foi possivel escrever no arquivo");
                	        	close(fd_orig);
	        	                close(fd_backup);
		                        return -1;
				}
				ns += n;
				nw -= n;
			} while (nw > 0);
		}
	}while(nr > 0);
	close(fd_orig);
	close(fd_backup);
    return 0;
}


/* --- */

/**
 * Cria uma estrutura TabelaArquivos vazia.
 * Entradas:
 *  - nome da pasta monitorada
 *  - nome da pasta backup
 *
 * Se as pastas não existirem, cria pastas novas.
 */
TabelaArquivos *tabela_criar(char *mon, char *bak)
{
    TabelaArquivos *nova = (TabelaArquivos *) malloc(sizeof(TabelaArquivos));
    strcpy(nova->dir_mon, mon);
    strcpy(nova->dir_bak, bak);
    nova->inicio = NULL;
    return nova;
}


/**
 * A partir da estrutura dirent do arquivo, cria uma nova entrada da tabela de
 * arquivos.
 *
 * Assume que o arquivo de origem localiza-se na pasta tabela->dir_mon.
 */
EntradaTabela *entrada_nova(struct dirent *origem)
{
    // Cria entrada
    EntradaTabela *entrada = (EntradaTabela *) malloc(sizeof(EntradaTabela));

    // Cria InfoArquivo para o arquivo original
    entrada->original = (InfoArquivo *) malloc(sizeof(InfoArquivo));
    entrada->original->inode = origem->d_ino;
    strcpy(entrada->original->nome, origem->d_name);
    strcpy(entrada->original->caminho, tabela->dir_mon);
    strcat(entrada->original->caminho, "/");

    // tamanho é um pouco + chato... obter status do arquivo original
    char buf[COMPR_DIR];
    caminho_completo(entrada->original, buf); // obtem caminho completo até o arquivo
    struct stat st;
    stat(buf, &st);

    // salva o seu tamanho
    entrada->original->tam = st.st_size;

    // Agora faz a cópia do arquivo
    entrada->backup = criar_backup(entrada->original, tabela->dir_bak);

    // entrada de tabela montada
    return entrada;
}


/**
 * Destroi a lista encadeada iniciando no nó atual.
 */
void destruir_lista(No *atual)
{
    if (atual == NULL)
    {
        return;
    }
    else
    {
        // destroi os elementos seguintes
        destruir_lista(atual->prox);

        // destroi o registro
        free(atual->registro->original);
        free(atual->registro->backup);
        free(atual->registro);

        // por fim, destroi o nó atual
        free(atual);
    }
}

/**
 * Arquivo novo:
 *  - Faz backup do arquivo
 *  - Cria uma nova EntradaTabela e armazena a informação de ambos os arquivos
 *  - Insere um registro na tabela de arquivos correspondente ao arquivo atual.
 */
void tabela_novo_arquivo(struct dirent *dirent_orig)
{
    tabela_inserir(entrada_nova(dirent_orig));      // composição de funções!
}


/**
 * Insere uma entrada de tabela na lista encadeada da tabela de arquivos.
 * A função altera a própria variável global.
 */
void tabela_inserir(EntradaTabela *entrada)
{
    No *novo = (No *) malloc(sizeof(No));
    novo->registro = entrada;
    novo->prox = tabela->inicio;
    tabela->inicio = novo;
}


/**
 * tabela_localizar_orig()
 * Retorna a entrada da tabela de arquivos na qual o arquivo original possui o
 * número de inode dado.
 * Retorna NULL caso a entrada não seja encontrada.
 */
EntradaTabela  *tabela_localizar_orig(No *atual, ino_t inode)
{
    // Implementa uma busca sequencial pela lista encadeada
    // Caso base: chave não encontrada
    if (atual == NULL)
        return NULL;

    // caso base 2: chave encontrada
    else if (atual->registro->original->inode == inode)
    {
        return atual->registro;
    }

    // recursão: continua busca no próximo nó
    else
    {
        return tabela_localizar_orig(atual->prox, inode);
    }
}