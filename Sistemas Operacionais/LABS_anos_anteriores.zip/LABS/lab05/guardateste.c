#include <assert.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include "sha1.c"

#define DIR_PADRAO  "./pasta"
#define BAK_PADRAO  "./pasta_backup"

#define BLOCO       4096
#define COMPR_DIR    256
#define COMPR_HASH    50    // confirmar este tamanho


//const char* hash(char *palavra)
void hash(char *palavra)
{
    printf("caculando uns hash aqui\n");
    char hashHex[21];
    char hexResult[41];

	SHA1(hashHex, palavra, strlen(palavra));

    int offset;
    for(offset = 0; offset < 20; offset++)
        sprintf( ( hexResult + (2*offset)), "%02x", hashHex[offset]&0xff);

    printf("%s\n", hexResult);

	//return hexResult;
}

void atualizar_backup(int fd_orig, int fd_backup)
{
    char buff_orig[BLOCO], buff_backup[BLOCO];
    int tam_orig, tam_backup;

    tam_orig = read(fd_orig, buff_orig, BLOCO);
    tam_backup = read(fd_backup, buff_backup, BLOCO);

    while(tam_orig > 0)
    {
        hash(buff_orig);
        hash(buff_backup);
        /*
        char* hash1 = hash(buff_orig);
        char* hash2 = hash(buff_backup);
    
        if(strcmp(hash1, hash2) != 0)
        {
            lseek(fd_backup, -tam_orig, SEEK_SET);
            write(fd_backup, buff_orig, tam_orig);
        }*/
        tam_orig = read(fd_orig, buff_orig, BLOCO);
        tam_backup = read(fd_backup, buff_backup, BLOCO);
    }
}

int main(){

    int fd1 = open("re.txt", O_RDONLY);
    int fd2 = open("r.txt", O_RDWR);

    atualizar_backup(fd1, fd2);

    return 0;
}