#include <assert.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include "sha1.c"

#define DIR_PADRAO  "./pasta"
#define BAK_PADRAO  "./pasta_backup"

#define BLOCO        512
#define COMPR_DIR    256
#define COMPR_HASH    50    // confirmar este tamanho


//const char* hash(char *palavra)
char* hash(char *palavra)
{
    char hashHex[21];
    char* hexResult = malloc(41*sizeof(char));

	SHA1(hashHex, palavra, strlen(palavra));

    int offset;
    for(offset = 0; offset < 20; offset++)
        sprintf( ( hexResult + (2*offset)), "%02x", hashHex[offset]&0xff);

    printf("%s\n", hexResult);

	return hexResult;
}

void atualizar_backup(int fd_orig, int fd_backup)
{
    char buff_orig[BLOCO], buff_backup[BLOCO];
    int tam_orig, tam_backup, cursor_backup, cursor_orig;

    tam_orig = read(fd_orig, buff_orig, BLOCO);
    tam_backup = read(fd_backup, buff_backup, BLOCO);
    cursor_backup = tam_backup;
    cursor_orig = tam_orig;

    while(tam_orig > 0)
    {
        printf("tam backup: %d  cursor: %d\ntam orig: %d  cursor: %d\n\n", tam_backup, cursor_backup, tam_orig, cursor_orig);

        if(strcmp(hash(buff_orig), hash(buff_backup)) != 0)
        {
            printf("atualizando\n");
            if(cursor_backup - tam_orig < 0) cursor_backup = 0;
            else cursor_backup = cursor_orig - tam_orig;

            printf("cursor: %d\n", cursor_backup);
            lseek(fd_backup, cursor_backup, SEEK_SET);
            write(fd_backup, buff_orig, tam_orig);
            cursor_backup += tam_orig;
            printf("cursor: %d\n\n", cursor_backup);
        }
        tam_orig = read(fd_orig, buff_orig, BLOCO);
        tam_backup = read(fd_backup, buff_backup, BLOCO);
        cursor_backup += tam_backup;
        cursor_orig += tam_orig;
    }
    ftruncate(fd_backup, cursor_orig);
}

int main(){

    int fd1 = open("Cachoeira.csv", O_RDONLY);
    int fd2 = open("Cachoeira_copia.csv", O_RDWR, O_APPEND);

    atualizar_backup(fd1, fd2);

    return 0;
}