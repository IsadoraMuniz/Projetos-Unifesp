/**
 * Sistemas Operacionais - 2018
 * Laboratório 5 - Map-Reduce
 *
 * Nomes: Guilherme Felipe Reis Duarte      RA: 120805
 *        Renata Sendreti Broder            RA: 112347
 *        
 * Data : 04/07/2018
 */

/* Anotações

Estrutura de uma entrada de diretorio.
É retornado por referencia por:

int scandir(const char *dirp, struct dirent ***namelist,
              int (*filter)(const struct dirent *),
              int (*compar)(const struct dirent **, const struct dirent **));

struct dirent {
    ino_t          d_ino;       // inode number
    off_t          d_off;       // offset to the next dirent
    unsigned short d_reclen;    // length of this record
    unsigned char  d_type;      // type of file; not supported
                                   by all file system types
    char           d_name[256]; // filename
};

-----------------
Estrutura stat: informações sobre um arquivo. É retornada por
referência pela função:
int stat(const char *path, struct stat *buf);

struct stat {
   dev_t     st_dev;     // ID of device containing file
   ino_t     st_ino;     // inode number
   mode_t    st_mode;    // protection
   nlink_t   st_nlink;   // number of hard links
   uid_t     st_uid;     // user ID of owner
   gid_t     st_gid;     // group ID of owner
   dev_t     st_rdev;    // device ID (if special file)
   off_t     st_size;    // total size, in bytes
   blksize_t st_blksize; // blocksize for filesystem I/O
   blkcnt_t  st_blocks;  // number of 512B blocks allocated   <-- Blocos de 512 bytes! Agora sim entendi!
   time_t    st_atime;   // time of last access
   time_t    st_mtime;   // time of last modification
   time_t    st_ctime;   // time of last status change
};

*/
#include <assert.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include "sha1.c"

#define DIR_PADRAO  "./pasta"
#define BAK_PADRAO  "./pasta_backup"

#define BLOCO       4096
#define COMPR_DIR    256
#define COMPR_HASH    50    // confirmar este tamanho

/* Estruturas de dados */
/**
 * InfoArquivo: armazena as informações básicas sobre um arquivo.
 */
typedef struct
{
    ino_t num_inode;                // número do i-node
    char  nome[COMPR_DIR];          // "lab5.c"
    char  caminho[COMPR_DIR];       // "./pasta/"      --> "./pasta/lab5.c"
    long long unsigned int tam;     // tamanho em bytes
    time_t st_mtime;                // última modificação
} InfoArquivo;


/**
 * EntradaTabela
 * Uma entrada na tabela de arquivos.
 * Cada entrada associa o i-node de um arquivo na pasta monitorada
 * ao i-node de um arquivo na pasta de backup.
 */
typedef struct EntradaTabela
{
    int alterado;
    InfoArquivo *original;
    InfoArquivo *backup;
    struct EntradaTabela *prox;
} EntradaTabela;

/**
 * TabelaArquivos
 * Uma tabela que relaciona cada arquivo na pasta monitorada
 * com os arquivos na pasta backup.
 */
typedef struct
{
    char dir_mon[COMPR_DIR];    // "./pasta"
    char dir_bak[COMPR_DIR];    // "./pasta_backup"

    EntradaTabela *inicio, *fim;
    int n_arqs;
    /* TODO: definir a estrutura da tabela de arquivos. Árvore? Lista encadeada? */
    /* Usar estrutura EntradaTabela como registro. */
} TabelaArquivos;

TabelaArquivos *tabela_criar(char *, char *);     // cria uma nova tabela


/* Variaveis globais */
pthread_t id_thread;
TabelaArquivos *tabela;


/* --- Funções auxiliares --- */
char* hash(char *palavra);
EntradaTabela * tabela_localizar_orig(ino_t num_inode);
void atualizar();
char ** buscaRemocao(struct dirent **listaOrig, int o, struct dirent **listaBackup, int b);

/* --- Funções do backup --- */
void iniciar_backup(char *, char *);
int copiar_arquivo(char *caminho, char *destino);
int atualizar_backup(int fd_orig, int fd_backup);
void finalizar_backup();
EntradaTabela * tabela_inserir(struct dirent *arquivo);

/**
 * monitorar()
 * Monitora a pasta dir_mon. É executada por uma thread auxiliar.
 * Passos:
 *
 * 1. Obtém a lista de todos os arquivos atualmente na pasta monitorada
 * 2. Para cada arquivo, verifica se já há uma entrada desse arquivo na
 *    tabela de arquivos - a verificação é feita pelo seu i-node.
 * 3. Se não existir, o arquivo é novo:
 *    3.1 *Copia* o arquivo para o diretorio de backup
 *    3.2 Cria uma entrada na tabela para esse arquivo.
 *
 * 4. Se existir, verifica se houve alterações no arquivo em relação ao backup.
 *    4.1 Se houve alterações (diferença de hash entre arquivo atual e o backup),
 *        *atualiza* o backup.
 *    4.2 Caso contrário, não faz nada.
 *
 * 5. Por fim, percorre a tabela em busca de arquivos que não existem mais na pasta
 *    monitorada.
 *    5.1 Se encontrado, apaga o arquivo de backup e remove a entrada da tabela de
 *        arquivos.
 *
 */
void *monitorar(void *arg)
{
    // inicia laço infinito
    while (true)
    {
        //intervalo de tempo de verificação
        sleep(180);

        // 1. Obtém lista de arquivos da pasta sendo monitorada
        struct dirent **listaOrig, **listaBackup;
        int i;
        int n = scandir(tabela->dir_mon, &listaOrig, NULL, alphasort);
        if (n < 0) perror("Erro ao obter a lista de arquivos no diretorio monitorado");

        int b = scandir(tabela->dir_bak, &listaBackup, NULL, alphasort);
        if (b < 0) perror("Erro ao obter a lista de arquivos no diretorio de backup");

        // 2. Percorre a lista para verificar suas entradas na tabela.
        for (i = 0; i < n; i++)
        {
            EntradaTabela *entrada = tabela_localizar_orig(listaOrig[i]->d_ino); // localiza entre arquivos originais

            // 3. Se não existe entrada na tabela, cria o backup do arquivo
            if (entrada == NULL)
            {
                entrada = tabela_inserir(listaOrig[i]);    // insere arquivo entre os backups usando o seu struct dirent.
                copiar_arquivo(entrada->original->caminho, entrada->backup->caminho);
            }

            // 4. Se existe, calcula o hash do arquivo para confirmar alterações
            else
            {
                char buff_orig[entrada->original->tam];
                char buff_backup[entrada->backup->tam];

                int fd_orig = open(entrada->original->caminho, O_RDONLY);
                if(fd_orig == -1) perror("Nao foi possivel abrir o arquivo");

                int fd_backup = open(entrada->backup->caminho, O_RDWR, O_APPEND);
                if(fd_backup == -1) perror("Nao foi possivel abrir o arquivo");

                int tam_orig = read(fd_orig, buff_orig, entrada->original->tam);
                if(tam_orig == -1) perror("Nao foi possivel ler o arquivo");
                
                int tam_backup = read(fd_backup, buff_backup, entrada->backup->tam);
                if(tam_backup == -1) perror("Nao foi possivel ler o arquivo");

                if(strcmp(hash(buff_orig), hash(buff_backup)) != 0)
                {
                    // 4.1 - Atualizar o backup
                    lseek(fd_orig, 0, SEEK_SET);
                    lseek(fd_backup, 0, SEEK_SET);
                    // envia ambos os descritores de arquivos. Eles já estão no início do arquivo
                    atualizar_backup(fd_orig, fd_backup);
                }
                close(fd_backup);
                close(fd_orig);
            }

        }
        // 5. Procurar na tabela arquivos que foram apagados da pasta monitorada
        char **remover = buscaRemocao(listaOrig, n, listaBackup, b);
        if(remover != NULL){
            remove(remover);
        }

        atualizar();

    }

    return NULL;
}

/* --- função principal --- */
int main(int argc, char *argv[])
{

    char nome_dir_mon[COMPR_DIR];
    char nome_dir_bak[COMPR_DIR];

    // Verifica o número de argumentos
    if (argc == 1)
    {
        // pastas padrão
        printf("Executando programa usando pastas padrao.\n");
        strcpy(nome_dir_mon, DIR_PADRAO);
        strcpy(nome_dir_bak, BAK_PADRAO);
    }

    else if (argc == 3)
    {
        // pastas recebidas como entrada
        printf("Executando programa usando pastas dadas.\n");
        strcpy(nome_dir_mon, argv[1]);
        strcpy(nome_dir_bak, argv[2]);
    }

    // Numero incorreto de argumentos
    else
    {
        printf("Uso:\n");
        printf("%s\n", argv[0]);
        printf("%s <pasta monitorada> <pasta backup>\n", argv[0]);
        return -1;
    }

    // inicia backup
    iniciar_backup(nome_dir_mon, nome_dir_bak);

    // cria a thread para monitorar os arquivos
    if ( (pthread_create(&id_thread, NULL, monitorar, NULL)) == -1)
    {
        perror("Nao foi possivel criar thread");
        return -1;
    }

    // Aguarda usuário finalizar o programa
    char c;
    printf("Pressione enter para finalizar o programa.\n");
    scanf("%c", &c);

    // Encerra as atividades
    finalizar_backup();
    return 0;
}

/**
 * iniciar_backup()
 *
 * Inicia as variáveis globais.
 * Verifica se pastas existem; cria as pastas caso contrário.
 */
void iniciar_backup(char *nome_dir_mon, char *nome_dir_bak)
{
    // Cria tabela de arquivos vazia
    tabela = tabela_criar(nome_dir_mon, nome_dir_bak);

    // Verifica se diretórios existem e os cria, caso contrário.
    // https://stackoverflow.com/questions/7430248/creating-a-new-directory-in-c
    struct stat st;
    int res;
    if (stat(nome_dir_mon, &st) == -1)
    {
        res = mkdir(nome_dir_mon, 0777);
        if (res == -1) perror("Nao foi possivel criar diretorio de monitoramento.");
    }

    if (stat(nome_dir_bak, &st) == -1)
    {
        mkdir(nome_dir_mon, 0777);
        if (res == -1) perror("Nao foi possivel criar diretorio de backup.");
    }

}

/* --- */

int copiar_arquivo(char *origem, char *destino){

    int fd_orig, fd_backup;

    fd_orig = open(origem, O_RDONLY);
	if (fd_orig == -1){
		perror("Nao foi possivel abrir o arquivo");
        return -1;
	}

	mode_t mode = S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH;
	fd_backup = open(destino, O_CREAT | O_WRONLY, mode);
	if(fd_backup == -1) {
		perror("Nao foi possivel abrir o arquivo");
		close(fd_orig);
        return -1;
	}

	int nr, ns, nw, n;
	char buffer[BLOCO];
	void *ptr_buff;
	do {
		nr = read(fd_orig, buffer, BLOCO);
		if (nr == -1) {
			perror("Nao foi possivel ler o arquivo");
			close(fd_orig);
			close(fd_backup);
			return -1;
		}
		else if (nr > 0) {
			ptr_buff = buffer;
			nw = nr;
			ns = 0;
			do {
				n = write(fd_backup, ptr_buff + ns, nw);
				if (n == -1) {
					perror("Nao foi possivel escrever no arquivo");
                	        	close(fd_orig);
	        	                close(fd_backup);
		                        return -1;
				}
				ns += n;
				nw -= n;
			} while (nw > 0);
		}
	}while(nr > 0);
	close(fd_orig);
	close(fd_backup);
    return 0;
}

int atualizar_backup(int fd_orig, int fd_backup)
{
    char buff_orig[BLOCO], buff_backup[BLOCO];
    int tam_orig, tam_backup, cursor_backup, cursor_orig, wb;

    tam_orig = read(fd_orig, buff_orig, BLOCO);
    tam_backup = read(fd_backup, buff_backup, BLOCO);
    cursor_backup = tam_backup;
    cursor_orig = tam_orig;

    while(tam_orig > 0)
    {
        // Compara blocos dos arquivos, se for diferente, reescreve no backup
        if(strcmp(hash(buff_orig), hash(buff_backup)) != 0)
        {
            if(cursor_backup - tam_orig < 0) cursor_backup = 0;
            else cursor_backup = cursor_orig - tam_orig;

            lseek(fd_backup, cursor_backup, SEEK_SET);
            wb = write(fd_backup, buff_orig, tam_orig);
            if(wb == -1){
                perror("Nao foi possivel escrever no arquivo");
                return -1;
            }
            cursor_backup += tam_orig;
        }
        tam_orig = read(fd_orig, buff_orig, BLOCO);
        if(tam_orig == -1){
            perror("Nao foi possivel ler o arquivo");
            return -1;
        }
        tam_backup = read(fd_backup, buff_backup, BLOCO);
        if(tam_backup == -1){
            perror("Nao foi possivel ler o arquivo");
            return -1;
        }
        cursor_backup += tam_backup;
        cursor_orig += tam_orig;
    }
    ftruncate(fd_backup, cursor_orig);
}

//https://www.devmedia.com.br/forum/sha1-ou-md5/580909
char* hash(char *palavra)
{
    char hashHex[21];
    char* hexResult = malloc(41*sizeof(char));

	SHA1(hashHex, palavra, strlen(palavra));

    int offset;
    for(offset = 0; offset < 20; offset++)
        sprintf( ( hexResult + (2*offset)), "%02x", hashHex[offset]&0xff);

	return hexResult;
}

/**
 * Cria uma estrutura TabelaArquivos vazia.
 * Entradas:
 *  - nome da pasta monitorada
 *  - nome da pasta backup
 *
 * Se as pastas não existirem, cria pastas novas.
 */
TabelaArquivos *tabela_criar(char *mon, char *bak)
{
    TabelaArquivos *nova = (TabelaArquivos *) malloc(sizeof(TabelaArquivos));
    strcpy(nova->dir_mon, mon);
    strcpy(nova->dir_bak, bak);

    nova->inicio = NULL;
    nova->fim = NULL;
    nova->n_arqs = 0;
    // TODO: outros campos
    return nova;
}

EntradaTabela *tabela_localizar_orig(ino_t num_inode){
    if(tabela->inicio == NULL) return NULL;
    EntradaTabela *percorre = tabela->inicio;
    while(percorre != NULL){
        if(percorre->original->num_inode == num_inode){
            percorre->alterado=1;
            return percorre;
        }
        percorre = percorre->prox;
    }
    return NULL;
}

EntradaTabela* tabela_inserir(struct dirent *arquivo){
    struct stat *buf;
    int s = stat(arquivo->d_name, buf);
    char caminho[COMPR_DIR];
    strcat(strcpy(caminho, tabela->dir_mon), arquivo->d_name);

    EntradaTabela *nova = malloc(sizeof(EntradaTabela));
    nova->prox = NULL;
    nova->alterado = 1;

    nova->original->num_inode = buf->st_ino;
    nova->original->tam = buf->st_size;
    nova->original->st_mtime = buf->st_mtime;
    strcpy(nova->original->nome, caminho);

    nova->backup->tam = buf->st_size;
    nova->backup->st_mtime = buf->st_mtime;
    strcat(strcpy(caminho, tabela->dir_bak), arquivo->d_name);
    strcpy(nova->original->nome, caminho);
    
    if(tabela->inicio == NULL)
        tabela->inicio = nova;
    else
        tabela->fim->prox = nova;
    tabela->fim = nova;
    tabela->n_arqs++;

    return nova;
}

char ** buscaRemocao(struct dirent **listaOrig, int o, struct dirent **listaBackup, int b){
    int i = 0, j = 0, d = 0;
    char **remover;

    while(){
        if(listaBackup[i] != listaOrig[i]){
            remover = realloc(remover, (d+1)*sizeof(char*)
        }
    }
}

void atualizar(){
    EntradaTabela *percorre = tabela->inicio;
    while(percorre != NULL){
        percorre->alterado = 0;
        percorre = percorre->prox;
    }
}