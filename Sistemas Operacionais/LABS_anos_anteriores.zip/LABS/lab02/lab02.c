/**
 * parte1.c
 *
 * Sistemas Operacionais - 2018
 * Laboratório 2 - Map-Reduce
 *
 * Integrantes:
 * 1. Renata Sendreti Broder            RA: 112347
 * 2. Guilherme Felipe Reis Duarte      RA: 120805
 *
 * Compilar:
 * make parte1
 *
 * Execução:
 * ./map-reduce entrada
 *
 * Neste primeiro programa, temos as funções map() funcionando com threads.
 */

#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <pthread.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <math.h>
#include <semaphore.h>
#include "sha1.c"

#define N 5           // numero de threads
#define TAM 1023      // tamanho da tabela hash

/**
 * verbete: estrutura correspondente a uma palavra no texto.
 *          A estrutura é uma lista linear.
 *  - palavra   (char *)    palavra encontrada
 *  - freq      (int)       número de ocorrências da palavra no texto
 *  - prox      (verbete *) ponteiro para a próxima palavra.
 */
typedef struct verbete
{
    char* palavra;
    int freq;
    struct verbete* prox;
} verbete;

/**
 * Cria um novo verbete com a palavra dada
 */
verbete *novo_verbete(char *palavra)
{
    verbete *novo = malloc(sizeof(verbete));
    novo->palavra = calloc(1 + strlen(palavra), sizeof(char));
    strcpy(novo->palavra, palavra);
    novo->freq = 1;
    novo->prox = NULL;
    return novo;
}


/**
 * Dada uma cadeia de verbetes, libera a memória ocupada pela cadeia inteira.
 */
void destruir_verbete(verbete *inicio)
{
    if (inicio == NULL)
    {
        return;
    }
    else
    {
        destruir_verbete(inicio->prox);
        free(inicio->palavra);
        free(inicio);
    }
}

/**
 * Dicionario: implementação de uma tabela hash, cujo tamanho é dado pela
 *             constante TAM.
 *             Cada entrada é um verbete como definido acima.
 */
typedef struct dicionario
{
    verbete *dic[TAM];
    /*NOVIDADES*/
    sem_t semaforo[TAM];
} dicionario;

/**
 * Cria um novo dicionário.
 * Retorna: um ponteiro para o dicionario criado.
 */
dicionario *novoDicionario()
{
    dicionario *novo = (dicionario *) malloc(sizeof(dicionario));
    int i;
    for(i=0; i<TAM; i++)
    {
        novo->dic[i] = NULL;
        /*NOVIDADES*/
        //inicializa o semaforo de cada posicao da tabela hash
        if ((sem_init(&novo->semaforo[i], 0, 1)) == -1)
        {
            printf("erro ao criar semaforo\n");
            exit(-1);
        }
    }
    return novo;
}

/**
 * Libera toda a memória utilizada pelo dicionário dado.
 * Para isso, deve-se percorrer todas as entradas do dicionario e liberar
 * a memória de cada verbete.
 */
void destruir_dicionario(dicionario *dic)
{
    int i;
    for (i = 0; i < TAM; i++)
    {
        destruir_verbete(dic->dic[i]);
        sem_destroy(&dic->semaforo[i]);
    }
    free(dic);
}


unsigned long int HexToDec(char hexVal[]){
    int len = strlen(hexVal);
    int base = 1;
    unsigned long int dec_val = 0;
    int i;

    for (i=len-1; i>=0; i--){
        if (hexVal[i]>='0' && hexVal[i]<='9'){
            dec_val += (hexVal[i] - 48)*base;
            base = base * 16;
        }
        else if (hexVal[i]>='A' && hexVal[i]<='F'){
            dec_val += (hexVal[i] - 55)*base;
            base = base*16;
        }
    }

    return dec_val;
}


/**
 * Interface com a função hash. Retorna um inteiro associado à palavra dada.
 */
unsigned long int hash(char *palavra)
{
    char hashHex[21];
    char hexResult[41];

	SHA1(hashHex, palavra, strlen(palavra));

    int offset;
    for(offset = 0; offset < 20; offset++)
        sprintf( ( hexResult + (2*offset)), "%02x", hashHex[offset]&0xff);

	return HexToDec(hexResult);
}


/**
 * Dado o dicionário, a palavra e sua entrada, insere-a no dicionário.
 */
void inserirPalavra(dicionario *lista, char *palavra, int hashInt)
{

    // Cria nova entrada no dicionario se a entrada for vazia
	if (lista->dic[hashInt] == NULL)
	{
		verbete *aux = novo_verbete(palavra);
		lista->dic[hashInt] = aux;
    }

    // Atualiza a entrada se existir; caso contrário adiciona o verbete ao início da lista
	else
	{
        verbete *percorre = lista->dic[hashInt];
        while(percorre != NULL){
            if(!strcmp(percorre->palavra, palavra))
            {
                percorre->freq++;
                return;
            }
            percorre = percorre->prox;

        }
        verbete *aux = novo_verbete(palavra);
        aux->prox = lista->dic[hashInt];
        lista->dic[hashInt] = aux;
    }
}

void inserePalavraMap(dicionario *lista, char *palavra)
{
	int hashInt = hash(palavra) % TAM;

    //down no semaforo dq posicao na qual se quer adicionar uma palavra
    sem_wait(&lista->semaforo[hashInt]);

    // insere a palavra normalmente
    inserirPalavra(lista, palavra, hashInt);

    //up no semaforo da posicao na qual uma palavra foi adicionda
    sem_post(&lista->semaforo[hashInt]);
}


void imprimeDic(dicionario *lista){
    int i;
    verbete *imprime;

    for(i=0; i<TAM; i++){
        imprime = lista->dic[i];
        while(imprime != NULL){
            printf("(%s, %d)\n", imprime->palavra, imprime->freq);
            imprime = imprime->prox;
        }
    }
}

/* ------------------------------ */

/**
 * blocoMap: O bloco de texto a ser enviado para a função map().
 *  - caminho   (char *)    Nome do arquivo a ser lido
 *  - inicio    (int)       Posição inicial do bloco. Início do arquivo = 0.
 *  - fim       (int)       Posição final do bloco; bytes lidos não incluem o byte fim, de forma que
 *                          os bytes lidos estão no intervalo: inicio <= byte < fim.
 *                          Exemplo: inicio = 100, fim = 200; bytes lidos: 100, 101, 102, ..., 198, 199.
 *  - tamBloco  (int)       Tamanho do bloco, em bytes. É dado por (fim - inicio).
 */
typedef struct blocoMap
{
    char* caminho;
    int inicio;
	int fim;
    int tamBloco;
} blocoMap;


int caracterValido(char c){
	if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= 0 && c <= 9))
		return 1;
	return 0;
}


/**
 * Separa o arquivo indicado em caminho em n blocos.
 * Retorna: ponteiro para o vetor de blocoMap.
 */
blocoMap **criar_blocos(char *caminho, int n)
{
    blocoMap **bmap = (blocoMap **) malloc(n*sizeof(blocoMap *));

    // Abre arquivo e obtém o seu tamanho
    int fd_arq = open(caminho, O_RDONLY);
	int tamArq= lseek(fd_arq, 0, SEEK_END);

	// Inicia divisão dos blocos
	int i;
	int tamBloco = tamArq/n;                                        // tamanho padrão de blocos. Ele é ajustado a cada bloco.
	for(i=0; i<n; i++)
    {
        // Cria o bloco
        bmap[i] = (blocoMap *) malloc(sizeof(blocoMap));

        // salva nome do arquivo
		bmap[i]->caminho = (char *) malloc((strlen(caminho) + 1)*sizeof(char));
		strcpy(bmap[i]->caminho, caminho);

		// ajusta inicio do bloco
		bmap[i]->inicio = (i == 0) ? 0 : bmap[i-1]->inicio + bmap[i-1]->tamBloco;

		// verifica final do bloco
		bmap[i]->fim      = (i == n - 1) ? tamArq : (i + 1)*tamBloco;
		bmap[i]->tamBloco = bmap[i]->fim - bmap[i]->inicio;             // tamanho do bloco antes do ajuste do fim


		//setando o fim do bloco - se esta em meio de palavra, vai ate o proximo espaco
		char verifica;
		lseek(fd_arq, bmap[i]->fim, SEEK_SET);
		read(fd_arq, &verifica, 1);
    	while (bmap[i]->fim < tamArq && caracterValido(verifica))
    	{
            bmap[i]->fim++;                       // incrementa o byte final
            bmap[i]->tamBloco++;                  // incrementa tamanho do bloco
    		read(fd_arq, &verifica, 1);           // lê próximo byte
    	}
    }

    // finalizar
    close(fd_arq);
    return bmap;
}


/**
 * Libera a memória ocupada por um bloco individual
 */
void destruir_bmap(blocoMap *bmap)
{
    free(bmap->caminho);
    free(bmap);
}

//remove caracteres especiais e deixa tudo minusculo
char* formata(char* texto){
    char* formatado = NULL;
    int i = 0, j = 0, len = strlen(texto);

    while(i < len)
    {
        if(caracterValido(texto[i]) || isspace(texto[i])){
            formatado = realloc(formatado, (j+2)*sizeof(char));
            if(texto[i] >= 65 && texto[i] <= 90)
				formatado[j]  = texto[i]+32;
			else if (isspace(texto[i]))
			    formatado[j] = ' ';
			else
				formatado[j]  = texto[i];
            j++;
        }
        i++;
    }
    formatado[j] = '\0';

    free(texto);        // libera a memoria do ponteiro texto e retorna o texto formatado.
    return formatado;
}


/**
 * EntradaReduce:
 *  - parcial    (dicionario *)  O dicionário produzido como resultado de uma execução do map()
 *  - central    (dicionario *)  Ponteiro para o dicionário central
 */
typedef struct EntradaReduce
{
    dicionario *parcial;
    dicionario *central;
} EntradaReduce;

EntradaReduce *novo_arg_reduce(dicionario *d1, dicionario *d2)
{
    EntradaReduce *novo = malloc(sizeof(EntradaReduce));
    novo->parcial = d1;
    novo->central = d2;
    return novo;
}

void destruir_arg_reduce(EntradaReduce *entrada)
{
    free(entrada);
}


/**
 * Implementação da função map.
 * Dado um bloco de texto, retora um dicionario (tabela hash) parcial.
 */
void *map(void *args)
{
	blocoMap *bloco = (blocoMap*)args;

    // Lê o bloco
    char* blocoTexto = (char*) calloc((bloco->tamBloco+1), sizeof(char));   // aloca memória e inicia-a com zeros ('\0')
    int f = open(bloco->caminho, O_RDONLY);
    lseek(f, bloco->inicio, SEEK_SET);
    read(f, blocoTexto, bloco->tamBloco);
	close(f);

    // Processa o texto
	blocoTexto = formata(blocoTexto);
	//printf("bloco: %s\n", blocoTexto);
	dicionario *lista = novoDicionario();

    // Insere palavras no dicionario
	char *delim = " ", *p;
    char *str = strtok_r(blocoTexto, delim, &p);
    while (str)
    {
		inserePalavraMap(lista, str);
        str = strtok_r(NULL, delim, &p);
    }
    free(blocoTexto);   // libera a memória utilizada pelo texto

    return lista;

}


/**
 * Implementação da função reduce()
 */
void *reduce(void *args)
{
    EntradaReduce dicionarios = *((EntradaReduce *) args);  // converte os argumentos pra estrutura correta

    // percorre o dicionario parcial e vai inserindo cada palavra encontrada no dicionario central
    int i;
    for (i = 0; i < TAM; i++)
    {
        verbete *percorre = dicionarios.parcial->dic[i];
        while (percorre != NULL)
        {
            int j;
            for (j = 0; j < percorre->freq; j++)
            {
                inserePalavraMap(dicionarios.central, percorre->palavra);
            }
            percorre = percorre->prox;
        }
    }

    // este reduce não precisa retornar argumentos.
    return NULL;
}


/*  MAIN */
/* Função main não implementa ainda barreiras nem semáforos. */
int main(int argc, char **argv){

    // Verifica argumentos
    if (argc != 2)
    {
        printf("Uso: %s nome_arquivo\n", argv[0]);
        return -1;
    }

	// Cria os blocos a serem passados para a função map
	blocoMap **blocos = criar_blocos(argv[1], N);

	// criar threads e executar maps para cada bloco
	int i;
	pthread_t threads[N];
	for (i = 0; i < N; i++)
	{
	    pthread_create(&threads[i], NULL, map, blocos[i]);
	}

	// Cria vetor de dicionarios parciais
	dicionario **parciais = malloc(N * sizeof(dicionario *));

    // receber os dicionarios parciais das threads.
    // O proprio pthread_join aguarda a finalização da execução das threads: não foi necessário implementar barreira aqui!
    for (i = 0; i < N; i++)
    {
        void *aux;
        pthread_join(threads[i], &aux);
        parciais[i] = (dicionario *) aux;
    }

    // Cria dicionário central
    dicionario *central = novoDicionario();

    // Executa Reduce para cada dicionario parcial e imprime dicionario resultante
    EntradaReduce *argsReduce[N];
    for (i = 0; i < N; i++)
    {
        argsReduce[i] = novo_arg_reduce(parciais[i], central);
        pthread_create(&threads[i], NULL, reduce, argsReduce[i]);
    }

    // Aguarda a finalização de cada thread
    for (i = 0; i < N; i++)
    {
        pthread_join(threads[i], NULL);
        destruir_dicionario(parciais[i]);
        destruir_arg_reduce(argsReduce[i]);
    }

    imprimeDic(central);

    // Finalizar: libera a memória utilizada por todos os ponteiros
    for (i = 0; i < N; i++)
    {
        destruir_bmap(blocos[i]);
    }
    free(blocos);
    free(parciais);
    destruir_dicionario(central);
    return 0;
}