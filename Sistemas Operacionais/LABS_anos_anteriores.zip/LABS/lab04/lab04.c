/*
 Sistemas Operacionais - Noturno - 2018
 Laboratório 4 - Gerenciamento de memória

 Renata Sendreti Broder            RA: 112347
 */

#include <stdio.h>
#include <stdlib.h>
#define MAX_RAM 10
#define MAX_VIRT 30
#define TEMPO_TOTAL 40000
#define CLOCK 5

int tempo_clock = 0;
int tempo_decorrido = 0;


/*
Estruturas que serão utilizadas para as memórias RAM e virtual
*/

// Página possui seu endereço (id) na memória virtual, uma variável de controle (r) e o tempo da ultima referenciação (em iterações)
typedef struct tipoPagina{
    int id;
    int r;
    int ultimaRef;
}tipoPagina;

// MemoriaRAM possui o tempo de inicio do programa (para definir qual das páginas sairá da memória para dar lugar a outra),
// o controle do índice da lista circular (que corresponde à memória RAM) e da quantidade de páginas na memória
typedef struct tipoMemoriaRAM{
    int indice;
    int nUsados;
    tipoPagina *lista;
}tipoMemoriaRAM;

/*
Aloca espaço para memRAM
Inicializa seus valores para que não haja página alguma nela
Define o tempo inicial
*/
tipoMemoriaRAM *inicializaMemRAM(tipoMemoriaRAM *memoria){
    memoria = malloc(sizeof(tipoMemoriaRAM));
    memoria->lista = malloc(MAX_RAM*sizeof(tipoPagina));
    memoria->indice = 0;
    memoria->nUsados = 0;

    return memoria;
}

/*
Aloca espaço para memVirtual
Insere os endereços por página (id)
Insere 0 para o controle r em cada página - significa que ela não está na memRAM
*/
tipoPagina* inicializaMemVirtual(tipoPagina *memoria){
    memoria = malloc(MAX_VIRT*sizeof(tipoPagina));
    int i;
    for(i=0; i<MAX_VIRT; i++){
        memoria[i].id = i;
        memoria[i].r = 0;
        memoria[i].ultimaRef = 0;
    }
    return memoria;
}

/*
Busca id da memória referenciada na memRAM
Retorno: índice na memRAM da página, se encontrada
         -1 se página não se encontra na memRAM
*/
int naRAM(tipoMemoriaRAM *memRAM, int id){
    int i; 
    for(i = 0; i<MAX_RAM; i++){
        if(memRAM->lista[i].id == id) return i;
    }
    return -1;
}

void zerarRef(tipoMemoriaRAM *memRAM){
    int i;
    for(i=0; i<MAX_RAM; i++)
        memRAM->lista[i].ultimaRef = 0;
    tempo_clock = 0;
    return;
}


int acesso(int id, int iteracao, tipoMemoriaRAM *memRAM, tipoPagina *memVirtual, int tau){
    tipoPagina nova = memVirtual[id];

    if(tempo_clock == CLOCK)
        zerarRef(memRAM);
    
    int i = naRAM(memRAM, nova.id);
    if(i != -1){ // se ja estiver na memRAM
        memRAM->lista[i].ultimaRef = iteracao; //atualiza o tempo
        memRAM->lista[i].r = 1; // atualiza a referenciacao
        return 1;
    }
    else{ //se não estiver na memRAM
        nova.ultimaRef = iteracao; // atualiza o tempo
        nova.r = 1; // atualiza a referenciacao
        if(memRAM->nUsados < MAX_RAM){ // se ainda houver espaco na memRAM, apenas coloca no proximo espaco vazio
            memRAM->lista[memRAM->indice] = nova;
            memRAM->nUsados++;
            memRAM->indice = (memRAM->indice + 1) % MAX_RAM;
            return 0;
        }
        else{ // se não houver mais espaço na memória, tem que selecionar quem vai tirar
            //printf("memoria cheia %d, %d\n", iteracao, memRAM->lista[memRAM->indice].ultimaRef);
            while(1){
                if(memRAM->lista[memRAM->indice].r == 0){
                    if(tempo_decorrido - memRAM->lista[memRAM->indice].ultimaRef > tau){
                        memVirtual[memRAM->lista[memRAM->indice].id].r = 0; 
                        memVirtual[nova.id].r = 1; // atualiza a referenciacao
                        memRAM->lista[memRAM->indice] = nova;
                        return -1;
                    }
                }
                if(memRAM->lista[memRAM->indice].r == 1)
                    memRAM->lista[memRAM->indice].r = 0;

                memRAM->indice = (memRAM->indice + 1) % MAX_RAM;
            }
        }
    }
}


int main(){

    int tempo, tau, i, pagina, v, pgMiss, pgHit;
    for(tempo = 1000; tempo < TEMPO_TOTAL; tempo+=2000){
        printf("\nTempo total: %d\n", tempo);
        for(tau = 10; tau<410; tau+=50){
            tipoMemoriaRAM *memRAM;
            tipoPagina *memVirtual;

            memRAM = inicializaMemRAM(memRAM);
            memVirtual = inicializaMemVirtual(memVirtual);

            pgMiss = 0;
            pgHit = 0;
            
            for(i=0; i<tempo; i++){
                
                tempo_decorrido++;
                tempo_clock++;
                
                pagina = rand() % MAX_VIRT;
                //printf("sorteado: %d\n", pagina);
                v = acesso(pagina, i, memRAM, memVirtual, tau);
                if(v == 1) pgMiss++;
                else if(v == -1) pgHit++;
            }
            printf("Tau: %d, PageMiss: %.2f %%\n", tau, (float)((pgMiss*100)/(float)(pgHit+pgMiss)));
        }
    }
    return 0;
}