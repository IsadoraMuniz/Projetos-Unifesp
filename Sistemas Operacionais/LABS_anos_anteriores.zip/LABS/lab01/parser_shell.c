#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define TAM 300

char ** monta_comando(char *cmd, char *p){
    char **matriz = NULL; //cria uma lista de args em um comando
    int n_str = 0;

    char *delim = " ";
    char *str = strtok_r(cmd, delim, &p);
    while(str){
        matriz = realloc(matriz, (n_str+2)*sizeof(char*));
        if(n_str == 0){
            char *bin = malloc(sizeof(str)+5);
            strcpy(bin, "/bin/");
            strcat(bin, str);
            matriz[n_str] = calloc(n_str, strlen(bin));
            strcpy(matriz[n_str], bin);
        }
        else{
            matriz[n_str] = calloc(n_str, strlen(str));
            strncpy(matriz[n_str], str, strlen(str));
        }
        n_str++;
        str = strtok_r(NULL, delim, &p);
    }
    matriz[n_str] = NULL;

    return matriz;
}


int main(){
    char comandos[TAM];
    fgets(comandos, TAM, stdin);

    char ***matriz = NULL;
    char *delim = "|";
    char *p;

    int n_cmd = 0;
    char *cmd = strtok_r(comandos, delim, &p);
    while(cmd){
        matriz = realloc(matriz, (n_cmd+1)*sizeof(char**));
        matriz[n_cmd] = monta_comando(cmd, *(&p));
        n_cmd++;
        cmd = strtok_r(NULL, delim, &p);
    }
    printf("criou\n");
    
    //retirar o \n do ultimo
    int i = 0;
    while(matriz[n_cmd-1][i] != NULL) i++;
    matriz[n_cmd-1][i-1][strlen(matriz[n_cmd-1][i-1])-1] = '\0';
    


    int j;
    for(i=0; i<n_cmd; i++){
        j = 0;
        while(matriz[i][j] != NULL){
            printf("%s\n", matriz[i][j]);
            j++;
        }
    }

    return 0;
}
