//Renata Sendreti Broder, 112347

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/wait.h>
#define TAM 300

char ** monta_comando(char *cmd, char *p){
    char **matriz = NULL; //cria uma lista de args em um comando
    int n_str = 0;

    char *delim = " ";
    char *str = strtok_r(cmd, delim, &p);
    while(str){
        matriz = realloc(matriz, (n_str+2)*sizeof(char*));
        if(n_str == 0){
            char *bin = malloc(sizeof(str)+5);
            strcpy(bin, "/bin/");
            strcat(bin, str);
            matriz[n_str] = calloc(n_str, strlen(bin));
            strcpy(matriz[n_str], bin);
        }
        else{
            matriz[n_str] = calloc(n_str, strlen(str));
            strncpy(matriz[n_str], str, strlen(str));
        }
        n_str++;
        str = strtok_r(NULL, delim, &p);
    }
    matriz[n_str] = NULL;

    return matriz;
}

char ***monta_matriz(char *comandos, int *n_cmd){
    char ***matriz = NULL;
    char *delim = "|";
    char *p;

    (*n_cmd) = 0;
    char *cmd = strtok_r(comandos, delim, &p);
    while(cmd){
        matriz = realloc(matriz, ((*n_cmd)+1)*sizeof(char**));
        matriz[(*n_cmd)] = monta_comando(cmd, *(&p));
        (*n_cmd)++;
        cmd = strtok_r(NULL, delim, &p);
    }
    return matriz;
}

int main(){

    //while(1){
        char comandos[TAM];
        fgets(comandos, TAM, stdin);

        char ***matriz = NULL;
        int n_cmd = 0;
        matriz = monta_matriz(comandos, &n_cmd);

        int i = 0, j;
        while(matriz[n_cmd-1][i] != NULL) i++; //retirar o \n do ultimo
        matriz[n_cmd-1][i-1][strlen(matriz[n_cmd-1][i-1])-1] = '\0';
        //MATRIZ CRIADA

        int fd[n_cmd-1][2];

        for(i=0; i<(n_cmd-1); i++){
            if (pipe(fd[i]) < 0){
                perror("pipe()");
                return -1;
            }
        }
        //criar fd n_cmd-1
        pid_t pid[n_cmd];


        for(i=0; i<n_cmd; i++){
            pid[i] = fork();
            //ifpid[i] == -1) printf("Erro na criacao do processo %d\n", i+1);
            if(pid[i] == 0){

                for(j=0; j<n_cmd-1; j++){
                    if(i==0 && j!=0){
                        close(fd[j][0]);
                        close(fd[j][1]);
                    }
                    else if(i==n_cmd-1 && j!=i-1){
                        close(fd[j][0]);
                        close(fd[j][1]);
                    }
                    else if(j!=i && j!=i-1){
                        close(fd[j][0]);
                        close(fd[j][1]);
                    }
                }

                if(n_cmd != 1){
                    if(i==0){
                        close(fd[i][0]);
                        close(STDOUT_FILENO);
                        dup(fd[i][1]);
                        close(fd[i][1]);
                    }
                    else if(i!=0 && i!=(n_cmd-1)){
                        close(fd[i-1][1]);
                        close(STDIN_FILENO);
                        dup(fd[i-1][0]);
                        close(fd[i-1][0]);

                        close(fd[i][0]);
                        close(STDOUT_FILENO);
                        dup(fd[i][1]);
                        close(fd[i][1]);
                    }
                    else if(i==(n_cmd-1)){
                        close(fd[i-1][1]);
                        close(STDIN_FILENO);
                        dup(fd[i-1][0]);
                        close(fd[i-1][0]);
                    }
                }

                execvp(matriz[i][0], matriz[i]);
            }

        }
        //waitpid(-1, NULL, 0);
    //}
    return 0;
}
